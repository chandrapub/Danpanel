-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Vært: 127.0.0.1
-- Genereringstid: 30. 09 2019 kl. 23:03:47
-- Serverversion: 10.1.26-MariaDB
-- PHP-version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `danpanel_dk_test_db`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `adminuser`
--

CREATE TABLE `adminuser` (
  `adminuid` int(11) NOT NULL,
  `adminname` varchar(255) NOT NULL,
  `adminemail` varchar(255) NOT NULL,
  `adminpwd` varchar(255) NOT NULL,
  `adminphonenr` int(8) NOT NULL,
  `admintype` varchar(255) NOT NULL,
  `adminverify` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `adminuser`
--

INSERT INTO `adminuser` (`adminuid`, `adminname`, `adminemail`, `adminpwd`, `adminphonenr`, `admintype`, `adminverify`, `image`) VALUES
(26, 'Maher', 'Ma@danpanel.dk', '$2y$10$G5J9gw7kK7VJer/RBgdS.u.Qwzd4zrk4K7S.U4GrsiiuYU3mU2cLO', 20616138, 'offentlig', 1, 'uploads/5caf2b69550865.77273377.Baggrunds billede .jpeg'),
(28, 'Peter Nielsen', 'pn@danpanel.dk', '$2y$10$bo52xpG/GLXU5c7UR8sX7u1YSVROXq6Bn6Pne22hcrMJNQ4wZS/2W', 20574247, 'erhverv', 1, 'uploads/5cb07afd74fce1.73639416.b289f60a51e0b97d65a11d85eb7cf48a.jpg'),
(29, 'Maher', 'ma@danpanel.dk', '$2y$10$NywTzbVo6ec1VvWsFapkL.t2buAbSkNk1q0jGpHGxEG6unInvwhEy', 20616138, 'privat', 0, NULL),
(30, 'Chandra Shekhar Mondal', 'cm@danpanel.dk', '$2y$10$6EFjDBSgfc3yYJsYzJitXe2NcSc3bwYXQwhaq13BcBLwGfCOc0zKu', 71594741, 'erhverv', 1, NULL),
(31, 'Chandra Shekhar Mondal', 'cm@danpanel.dk', '$2y$10$ii9N0i7W5hnoWRCi0f9ToeOyfB1/HJz/wncOYng7EjCYSje3T47zi', 71594741, 'erhverv', 0, NULL),
(32, 'Chandra Shekhar Mondal', 'cm@danpanel.dk', '$2y$10$l0SIT7Pt4wBWh69zRa6jLuhUzJ.YBLw.lFterKiXl4OjHPlxMuiPO', 71594741, 'erhverv', 0, NULL),
(33, 'Chandra Shekhar Mondal', 'cm@danpanel.dk', '$2y$10$u9cos0pQRTtm09hUrmDRVePblcWusAG3V.jnWMf6PxQn1k0lNMLsW', 71594741, 'erhverv', 0, NULL),
(34, 'Chandra Shekhar Mondal', 'cm@danpanel.dk', '$2y$10$zgHYu4gESszpZjmCAejBZuvXRLZ0mgo6vyNwSwqNcvU5YvXK9krp.', 71594741, 'erhverv', 0, NULL);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `alarmovervaagning`
--

CREATE TABLE `alarmovervaagning` (
  `orderid` int(11) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sikkerhedscheck` datetime NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `firmaadresse` varchar(255) NOT NULL,
  `fakturaemail` varchar(255) NOT NULL,
  `ean` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `alarmovervaagning`
--

INSERT INTO `alarmovervaagning` (`orderid`, `kontaktperson`, `sikkerhedscheck`, `sagsnr`, `firmaadresse`, `fakturaemail`, `ean`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(1, 'Chandra Shekhar Mondal', '2019-06-27 15:33:00', '12', 'Klokkerhøjen 11 st', 'chandrapub@gmail.com', '23', '', 61, NULL, 0),
(2, 'Chandra Shekhar Mondal', '2019-07-01 18:06:00', 'test1', 'test', 'tithi124410@gmail.com', '33', '', 61, NULL, 0),
(3, 'test', '2019-07-11 23:00:00', 'qw', 'wwd', 'test@danpanel.dk', '0', 'ddg.dk', 63, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `alarmovervaagningcomments`
--

CREATE TABLE `alarmovervaagningcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `alarmovervaagninguserfiles`
--

CREATE TABLE `alarmovervaagninguserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `digitalisering`
--

CREATE TABLE `digitalisering` (
  `orderid` int(11) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `beskrivelse` text NOT NULL,
  `firmaadresse` varchar(255) NOT NULL,
  `fakturaemail` varchar(255) NOT NULL,
  `ean` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `digitalisering`
--

INSERT INTO `digitalisering` (`orderid`, `kontaktperson`, `sagsnr`, `beskrivelse`, `firmaadresse`, `fakturaemail`, `ean`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(5, 'Peter Nielsen', '99b', 'Arkiv system skal digitaliseres', 'testvej 44', 'test@testmail.dk', '0', '', 17, NULL, 0),
(6, 'Peter Tester', '11q', 'TEster digitalisering', 'testvej 44', 'Peter@soda.dk', '0', '', 17, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `digitaliseringcomments`
--

CREATE TABLE `digitaliseringcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `digitaliseringcomments`
--

INSERT INTO `digitaliseringcomments` (`commentid`, `timestamp`, `commenttext`, `uid`, `orderid`, `adminuid`) VALUES
(1, '2019-06-11 08:51:46', 'hej \r\n', NULL, 5, 26);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `digitaliseringuserfiles`
--

CREATE TABLE `digitaliseringuserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `erhvervlejemaal`
--

CREATE TABLE `erhvervlejemaal` (
  `orderid` int(11) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `typeaflokale` varchar(255) NOT NULL,
  `beskrivelse` text NOT NULL,
  `firmaadresse` varchar(255) NOT NULL,
  `budget` text NOT NULL,
  `kvadratmeter` int(11) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `erhvervlejemaal`
--

INSERT INTO `erhvervlejemaal` (`orderid`, `kontaktperson`, `sagsnr`, `typeaflokale`, `beskrivelse`, `firmaadresse`, `budget`, `kvadratmeter`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(4, 'Peter Nielsen', '22tr', 'Helsingør', 'kontor søges test', 'testvej 22', '30.000', 220, '', 17, NULL, 0),
(5, 'Peter Tester', '11s', 'Helsingør', 'Tester erhvervlejemål', 'Sodavej 44', '100.00', 112, '', 17, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `erhvervlejemaalcomments`
--

CREATE TABLE `erhvervlejemaalcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `erhvervlejemaaluserfiles`
--

CREATE TABLE `erhvervlejemaaluserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `fagforening`
--

CREATE TABLE `fagforening` (
  `orderid` int(11) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `booketmoede` datetime NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `fagforening`
--

INSERT INTO `fagforening` (`orderid`, `adresse`, `sagsnr`, `booketmoede`, `uid`, `adminuid`, `progressionoforder`) VALUES
(1, 'Industrigatan 20', '121', '2019-06-27 19:07:00', 61, NULL, 0),
(2, 'Frederikssundsvej 105. 1th', '105', '2019-08-31 11:11:00', 61, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `fagforeningcomment`
--

CREATE TABLE `fagforeningcomment` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` varchar(255) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `fagforeninguserfiles`
--

CREATE TABLE `fagforeninguserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `jobtilbud`
--

CREATE TABLE `jobtilbud` (
  `orderid` int(11) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `stilling` text NOT NULL,
  `booketmoede` datetime NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `jobtilbud`
--

INSERT INTO `jobtilbud` (`orderid`, `adresse`, `sagsnr`, `stilling`, `booketmoede`, `uid`, `adminuid`, `progressionoforder`) VALUES
(1, 'Ã˜stergrave 4', '12', 'test', '2019-06-22 02:22:00', 61, 30, 2);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `jobtilbudcomment`
--

CREATE TABLE `jobtilbudcomment` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` varchar(255) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `jobtilbuduserfiles`
--

CREATE TABLE `jobtilbuduserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kaffeloesning`
--

CREATE TABLE `kaffeloesning` (
  `orderid` int(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `currentsolution` varchar(255) NOT NULL,
  `amountprmonth` text NOT NULL,
  `monthleftoncurrentdeal` text NOT NULL,
  `amountofcoffeprmonth` text NOT NULL,
  `priceprkgcoffe` text NOT NULL,
  `typeoffutureproducts` varchar(255) NOT NULL,
  `uid` int(255) DEFAULT NULL,
  `adminuid` int(255) DEFAULT NULL,
  `progressionoforder` int(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kaffeloesningcomments`
--

CREATE TABLE `kaffeloesningcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kaffeloesninguserfiles`
--

CREATE TABLE `kaffeloesninguserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `koerebog`
--

CREATE TABLE `koerebog` (
  `orderid` int(11) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `beskrivelse` varchar(255) NOT NULL,
  `antal` int(11) NOT NULL,
  `moede` datetime NOT NULL,
  `firmaadresse` varchar(255) NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `koerebog`
--

INSERT INTO `koerebog` (`orderid`, `kontaktperson`, `sagsnr`, `beskrivelse`, `antal`, `moede`, `firmaadresse`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(5, 'Peter Tester', '11d', 'Tester kørebog erhverv', 2, '2019-04-16 10:00:00', 'testvej 44', '', 17, NULL, 0),
(12, 'Shekhar', '13', 'test test', 12, '2019-06-17 11:37:13', 'klokkerhojen', 'www.testsite.com', NULL, 30, 1),
(20, 'Chandra Shekhar Mondal', '33', 'test', 33, '2019-06-27 11:11:00', 'KlokkerhÃ¸jen 11 st', 'https://github.com/chandrapub', 61, 30, 1),
(21, 'Chandra', '12', 'TestTest', 23, '2019-06-27 03:33:00', 'Frederikssundsvej 105. 1th', 'www.mygalary121.com', 61, 30, 2),
(22, 'Chandra Shekhar', '2', 'test', 33, '2019-06-29 11:11:00', 'KlokkerhÃ¸jen 11 st', 'www.mysite1133.22com', 61, 30, 2),
(23, 'Chandra Shekhar Mondal', '33', 'test', 22, '2019-06-29 11:11:00', 'KlokkerhÃ¸jen 11 st', 'www.danpanel2211.dk', 61, 30, 2),
(24, 'Chandra Shekhar Mondal', '55', 'test', 23, '2019-06-29 03:33:00', 'KlokkerhÃ¸jen 11 st', '', 61, 30, 1);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `koerebogcomments`
--

CREATE TABLE `koerebogcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `koerebogcomments`
--

INSERT INTO `koerebogcomments` (`commentid`, `timestamp`, `commenttext`, `uid`, `orderid`, `adminuid`) VALUES
(1, '2019-06-14 13:12:49', '', NULL, 5, 26),
(2, '2019-06-14 13:13:14', 'hi test', NULL, 5, 26),
(3, '2019-06-28 09:18:16', 'hiii', NULL, 23, 30);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `koereboguserfiles`
--

CREATE TABLE `koereboguserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `leveringsinfo`
--

CREATE TABLE `leveringsinfo` (
  `order_id` int(12) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `postnummer` int(4) NOT NULL,
  `by` varchar(255) NOT NULL,
  `firmanavn` varchar(255) DEFAULT NULL,
  `cvr` int(10) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `offentligcomments`
--

CREATE TABLE `offentligcomments` (
  `commentid` int(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comment` varchar(255) DEFAULT NULL,
  `uid` int(255) DEFAULT NULL,
  `orderid` int(255) NOT NULL,
  `adminuid` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `offentligorders`
--

CREATE TABLE `offentligorders` (
  `orderid` int(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `typeoforder` varchar(255) NOT NULL,
  `startdate` date NOT NULL,
  `opstartsdate` datetime NOT NULL,
  `duration` int(255) NOT NULL,
  `hoursprweek` int(255) NOT NULL,
  `progressionoforder` int(255) NOT NULL,
  `uid` int(255) NOT NULL,
  `enddate` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `adminuid` int(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `offentliguserfiles`
--

CREATE TABLE `offentliguserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `produkt`
--

CREATE TABLE `produkt` (
  `produkt_id` int(12) NOT NULL,
  `produkt` varchar(255) NOT NULL,
  `billede` varchar(255) NOT NULL,
  `antal` int(11) NOT NULL,
  `pris` double(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `rengoering`
--

CREATE TABLE `rengoering` (
  `orderid` int(11) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `opgavetype` varchar(255) NOT NULL,
  `opgaveadresse` varchar(255) NOT NULL,
  `kvadratmeter` int(11) NOT NULL,
  `beskrivelse` text NOT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `rengoering`
--

INSERT INTO `rengoering` (`orderid`, `kontaktperson`, `sagsnr`, `opgavetype`, `opgaveadresse`, `kvadratmeter`, `beskrivelse`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(8, 'Peter Tester', '11a', 'test test', 'testvej 22', 221, 'Rengøring tester', '', 17, NULL, 0),
(9, 'Peter Tester', '11r', 'test test', 'testvej 22', 112, 'tester rengøring privat', '', 48, NULL, 0),
(10, 'Chandra Shekhar Mondal', '12', 'Test', 'Klokkerhøjen 11 st', 40, 'Test', '', 68, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `rengoeringcomments`
--

CREATE TABLE `rengoeringcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `rengoeringuserfiles`
--

CREATE TABLE `rengoeringuserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `renovering`
--

CREATE TABLE `renovering` (
  `orderid` int(11) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `typeafopgave` varchar(255) NOT NULL,
  `beskrivelse` varchar(255) NOT NULL,
  `booketmoede` datetime NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `renovering`
--

INSERT INTO `renovering` (`orderid`, `adresse`, `sagsnr`, `typeafopgave`, `beskrivelse`, `booketmoede`, `uid`, `adminuid`, `progressionoforder`) VALUES
(2, 'Frederikssundsvej 105. 1th', '12', 'Renovering Kitchen', 'test', '2019-06-28 03:34:00', 61, NULL, 0),
(3, 'Frederikssundsvej 105. 1th', '222', 'test', 'test', '2019-08-31 11:11:00', 61, NULL, 0),
(4, 'Frederikssundsvej 105. 1th', '105', 'Renovering Kitchen', '11', '2222-02-22 14:22:00', 61, NULL, 0),
(5, 'Frederikssundsvej 105. 1th', '1055', 'Renovering Kitchen', '11', '2222-02-22 14:22:00', 61, NULL, 0),
(6, 'Frederikssundsvej 105. 1th', '1055', 'Renovering Kitchen', '11', '2222-02-22 14:22:00', 61, NULL, 0);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `renoveringcomment`
--

CREATE TABLE `renoveringcomment` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` varchar(255) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `renoveringuserfiles`
--

CREATE TABLE `renoveringuserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `testtable`
--

CREATE TABLE `testtable` (
  `testNr` int(50) NOT NULL,
  `TestName` varchar(50) NOT NULL,
  `TestType` varchar(50) NOT NULL,
  `NoOfTest` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `testtable`
--

INSERT INTO `testtable` (`testNr`, `TestName`, `TestType`, `NoOfTest`) VALUES
(1, 'testCar', 'washing', '2');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `users`
--

CREATE TABLE `users` (
  `uid` int(255) NOT NULL,
  `typeofuser` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `phonenr` int(255) NOT NULL,
  `ean` varchar(255) DEFAULT NULL,
  `cvr` varchar(255) DEFAULT NULL,
  `foedselsdato` varchar(255) DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `nyhedsbrev` varchar(3) DEFAULT 'nej'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `users`
--

INSERT INTO `users` (`uid`, `typeofuser`, `name`, `email`, `pwd`, `phonenr`, `ean`, `cvr`, `foedselsdato`, `verify`, `image`, `nyhedsbrev`) VALUES
(17, 'erhverv', 'PeterTestErhverv', 'PedeB@gmail.com', '$2y$10$CufNvCDBP74dp3QdjSSFZOTxhPHf/OnCaF79fIseRes.Q64RaIMqe', 12345678, '', '61728394', '', 1, NULL, 'nej'),
(31, 'erhverv', 'Maher', 'maher.al.samarai87@gmail.com', '$2y$10$CYTGv03i0AfzfK940XS0COZFmRIkxIXlAxnRe6WcZ1WzCqqx6jDHm', 20616138, '', '38362925', '', 0, 'uploads/5cb07abecfe291.85777060.DP Logo .jpg', 'ja'),
(42, 'privat', 'Maher', 'maher.al.samarai87@gmail.com', '$2y$10$4xtngXrqjqd89qm3wLN3Du/v7i4mffP8eCZ2fL8djzy.Egd2zFglO', 20616138, '123456789', '38362925', '1990-02-02', 0, NULL, 'ja'),
(43, 'privat', 'Maher', 'maher_al_samarai@live.dk', '$2y$10$A2QCv74jb.liDL5cY6kEg.xp/EzUvZNvb.9yhK3dIGhOt0T8xspaW', 20616138, '', '', '1991-02-01', 0, NULL, 'ja'),
(46, 'offentlig', 'Peter Tester', 'PeterTesterDP@gmail.com', '$2y$10$JMrkayW9LuRgWbpTNmjHJ.SqZtyCDhDkYhkhgQHNnBIf.40MoLvx.', 12345678, '12312', '', '', 1, NULL, 'ja'),
(48, 'privat', 'Peter Tester', 'Pete9602@edu.easj.dk', '$2y$10$HszO/l2E6pPMjM05bz3isO1bU83Ka.eu9zwGUxXPw98ZinBk92k/u', 12345678, '', '', '1982-09-30', 1, NULL, 'nej'),
(49, 'privat', 'Anders Nielsen', 'anders93n@gmail.com', '$2y$10$T3EfDkQjyCALBmsMaZyiVOwd6ZDtXzgS////WapcDVYa9pJHSUsa2', 60825053, '', '', '1993-08-26', 0, NULL, 'nej'),
(51, 'erhverv', 'Allan Wisen', 'abwi@kemp-lauritzen.dk', '$2y$10$JbR5JKybJ3JJO4IZ60qkAeQqCvdQGTEeLDYBGPVLpwc1sfE.MkCEu', 31102958, '', '12345678', '', 0, NULL, 'ja'),
(55, 'privat', 'Emanuele Ambrosio', 'emanuambrosio.76@gmail.com', '$2y$10$cTrrYRsC7OYnKU5BSJHgleUieKfPTd8HDUxh2b3eS2MQKduO9/LzG', 22996322, '', '', '1976-07-22', 0, NULL, 'ja'),
(61, 'privat', 'Chandra Shekhar Mondal', 'tithi124410@gmail.com', '$2y$10$CElj2vbyqGIKWb2fi1RBC.eETyh2bVyDa2GTh.Momsl/FsfLpLICq', 71594741, '', '', '1982-11-02', 1, NULL, 'ja'),
(63, 'privat', 'Maher ', 'ma@ungesagen.dk', '$2y$10$FgY5KutFztcPMcsJWwT8OOEnqQ.txtPTvH7cARudWjt7uxRoXbbja', 20616138, '', '', '1987-02-11', 1, NULL, 'ja'),
(67, 'offentlig', 'Chandra Shekhar', 'chandrapub@yahoo.com', '$2y$10$f.LrBh/jfWuTw4W48nIpaeultA4qBQRPdWIdL7bfN/BSKkwa/cGCK', 71594741, '34686335', '', '', 0, NULL, 'ja'),
(68, 'erhverv', 'Chandra Shekhar Mondal', 'chandrapub@gmail.com', '$2y$10$WrG192A5KxkjI5kr5uVbZuXOtVUsOMRhP4CgvJodA/V9DSXJTIomK', 71594741, '', '38362925', '', 0, 'uploads/5d5e8ddc6cc8c9.12262040.CSM.jpg', 'ja'),
(69, 'erhverv', 'Chandra Shekhar Mondal', 'chandrapub@yahoo.com', '$2y$10$ozxRsXwoz42u.SQ9KzDao.VH06g9ZLPUdA02yutRAdaAU2NNPE1vy', 71594741, '', '38362925', '', 0, NULL, 'ja');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `vikarrekruttering`
--

CREATE TABLE `vikarrekruttering` (
  `orderid` int(11) NOT NULL,
  `virksomhedsnavn` varchar(255) NOT NULL,
  `kontaktperson` varchar(255) NOT NULL,
  `sagsnr` varchar(255) NOT NULL,
  `beskrivelse` text NOT NULL,
  `antal` int(11) NOT NULL,
  `typeafopgave` varchar(255) NOT NULL,
  `varighed` int(11) NOT NULL,
  `moedetid` varchar(255) NOT NULL,
  `opgaveadresse` varchar(255) NOT NULL,
  `firmaadresse` varchar(255) NOT NULL,
  `fakturaemail` varchar(255) NOT NULL,
  `ean` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL,
  `progressionoforder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `vikarrekruttering`
--

INSERT INTO `vikarrekruttering` (`orderid`, `virksomhedsnavn`, `kontaktperson`, `sagsnr`, `beskrivelse`, `antal`, `typeafopgave`, `varighed`, `moedetid`, `opgaveadresse`, `firmaadresse`, `fakturaemail`, `ean`, `website`, `uid`, `adminuid`, `progressionoforder`) VALUES
(2, 'Coop', 'Chandra', '6', 'Hellow', 2, 'Construction', 2, '', 'Glostrup', '2', 'Chandrapub@gmail.com', '3', '2', 68, 34, 1),
(4, 'Føtex', 'Chandra', '55', 'testing', 3, 'removation', 3, '', 'Frederikberg', 'Frederikberg', 'cm@danpanel.dk', '3333', 'www.mypage.com', 68, 34, 0),
(5, 'petertestfirma', 'Peter Tester', '11e', 'Tester vikar', 2, 'test test', 3, '10:00', 'testvej 22', 'testvej 44', 'test@test.dk', '', '', 17, NULL, 0),
(22, 'Fakta', 'Mondal', '2', 'Test', 3, 'Cleaning', 2, '', 'Emdrup', '2', 'Chandrapub@gmail.com', '34', '2', 68, 34, 2);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `vikarrekrutteringcomments`
--

CREATE TABLE `vikarrekrutteringcomments` (
  `commentid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `commenttext` text,
  `uid` int(11) DEFAULT NULL,
  `orderid` int(11) DEFAULT NULL,
  `adminuid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `vikarrekrutteringcomments`
--

INSERT INTO `vikarrekrutteringcomments` (`commentid`, `timestamp`, `commenttext`, `uid`, `orderid`, `adminuid`) VALUES
(1, '2019-04-24 10:55:54', 'hej', NULL, 5, 26),
(2, '2019-09-25 16:47:34', 'Hi \r\n', NULL, 2, 30);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `vikarrekrutteringuserfiles`
--

CREATE TABLE `vikarrekrutteringuserfiles` (
  `userfileid` int(11) NOT NULL,
  `userfilename` varchar(255) NOT NULL,
  `userfilepath` varchar(255) NOT NULL,
  `orderid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `vikarrekrutteringuserfiles`
--

INSERT INTO `vikarrekrutteringuserfiles` (`userfileid`, `userfilename`, `userfilepath`, `orderid`) VALUES
(1, '5cb5c46a763253.00593000.SSLTest.zip', '../uploads/5cb5c46a763253.00593000.SSLTest.zip', 5);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `webshoporder`
--

CREATE TABLE `webshoporder` (
  `webshoporder_id` int(12) NOT NULL,
  `order_id` int(12) NOT NULL,
  `produkt_id` int(12) NOT NULL,
  `prisialt` double(10,2) NOT NULL,
  `orderdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`adminuid`);

--
-- Indeks for tabel `alarmovervaagning`
--
ALTER TABLE `alarmovervaagning`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `alarmovervaagningcomments`
--
ALTER TABLE `alarmovervaagningcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `alarmovervaagninguserfiles`
--
ALTER TABLE `alarmovervaagninguserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `digitalisering`
--
ALTER TABLE `digitalisering`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `digitaliseringcomments`
--
ALTER TABLE `digitaliseringcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `digitaliseringuserfiles`
--
ALTER TABLE `digitaliseringuserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `erhvervlejemaal`
--
ALTER TABLE `erhvervlejemaal`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `erhvervlejemaalcomments`
--
ALTER TABLE `erhvervlejemaalcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `erhvervlejemaaluserfiles`
--
ALTER TABLE `erhvervlejemaaluserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `fagforening`
--
ALTER TABLE `fagforening`
  ADD PRIMARY KEY (`orderid`),
  ADD UNIQUE KEY `sagsnr_3` (`sagsnr`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`),
  ADD KEY `sagsnr` (`sagsnr`),
  ADD KEY `sagsnr_2` (`sagsnr`);

--
-- Indeks for tabel `fagforeningcomment`
--
ALTER TABLE `fagforeningcomment`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `fagforeninguserfiles`
--
ALTER TABLE `fagforeninguserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `jobtilbud`
--
ALTER TABLE `jobtilbud`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `jobtilbudcomment`
--
ALTER TABLE `jobtilbudcomment`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `jobtilbuduserfiles`
--
ALTER TABLE `jobtilbuduserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `kaffeloesning`
--
ALTER TABLE `kaffeloesning`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `kaffeloesningcomments`
--
ALTER TABLE `kaffeloesningcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `kaffeloesninguserfiles`
--
ALTER TABLE `kaffeloesninguserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `koerebog`
--
ALTER TABLE `koerebog`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `koerebogcomments`
--
ALTER TABLE `koerebogcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `koereboguserfiles`
--
ALTER TABLE `koereboguserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `leveringsinfo`
--
ALTER TABLE `leveringsinfo`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `adminid` (`adminuid`),
  ADD KEY `uid` (`uid`);

--
-- Indeks for tabel `offentligcomments`
--
ALTER TABLE `offentligcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `offentligorders`
--
ALTER TABLE `offentligorders`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `offentliguserfiles`
--
ALTER TABLE `offentliguserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `produkt`
--
ALTER TABLE `produkt`
  ADD PRIMARY KEY (`produkt_id`);

--
-- Indeks for tabel `rengoering`
--
ALTER TABLE `rengoering`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `rengoeringcomments`
--
ALTER TABLE `rengoeringcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `rengoeringuserfiles`
--
ALTER TABLE `rengoeringuserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `renovering`
--
ALTER TABLE `renovering`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `renoveringcomment`
--
ALTER TABLE `renoveringcomment`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `renoveringuserfiles`
--
ALTER TABLE `renoveringuserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Indeks for tabel `vikarrekruttering`
--
ALTER TABLE `vikarrekruttering`
  ADD PRIMARY KEY (`orderid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `vikarrekrutteringcomments`
--
ALTER TABLE `vikarrekrutteringcomments`
  ADD PRIMARY KEY (`commentid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `adminuid` (`adminuid`);

--
-- Indeks for tabel `vikarrekrutteringuserfiles`
--
ALTER TABLE `vikarrekrutteringuserfiles`
  ADD PRIMARY KEY (`userfileid`),
  ADD KEY `orderid` (`orderid`);

--
-- Indeks for tabel `webshoporder`
--
ALTER TABLE `webshoporder`
  ADD PRIMARY KEY (`webshoporder_id`),
  ADD KEY `produkt_id` (`produkt_id`),
  ADD KEY `order_id` (`order_id`) USING BTREE;

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `adminuid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- Tilføj AUTO_INCREMENT i tabel `alarmovervaagning`
--
ALTER TABLE `alarmovervaagning`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Tilføj AUTO_INCREMENT i tabel `alarmovervaagningcomments`
--
ALTER TABLE `alarmovervaagningcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `alarmovervaagninguserfiles`
--
ALTER TABLE `alarmovervaagninguserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `digitalisering`
--
ALTER TABLE `digitalisering`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Tilføj AUTO_INCREMENT i tabel `digitaliseringcomments`
--
ALTER TABLE `digitaliseringcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tilføj AUTO_INCREMENT i tabel `digitaliseringuserfiles`
--
ALTER TABLE `digitaliseringuserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `erhvervlejemaal`
--
ALTER TABLE `erhvervlejemaal`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Tilføj AUTO_INCREMENT i tabel `erhvervlejemaalcomments`
--
ALTER TABLE `erhvervlejemaalcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `erhvervlejemaaluserfiles`
--
ALTER TABLE `erhvervlejemaaluserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `fagforening`
--
ALTER TABLE `fagforening`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Tilføj AUTO_INCREMENT i tabel `fagforeningcomment`
--
ALTER TABLE `fagforeningcomment`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `fagforeninguserfiles`
--
ALTER TABLE `fagforeninguserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `jobtilbud`
--
ALTER TABLE `jobtilbud`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tilføj AUTO_INCREMENT i tabel `jobtilbudcomment`
--
ALTER TABLE `jobtilbudcomment`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `jobtilbuduserfiles`
--
ALTER TABLE `jobtilbuduserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `kaffeloesning`
--
ALTER TABLE `kaffeloesning`
  MODIFY `orderid` int(255) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `kaffeloesningcomments`
--
ALTER TABLE `kaffeloesningcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `kaffeloesninguserfiles`
--
ALTER TABLE `kaffeloesninguserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `koerebog`
--
ALTER TABLE `koerebog`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Tilføj AUTO_INCREMENT i tabel `koerebogcomments`
--
ALTER TABLE `koerebogcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Tilføj AUTO_INCREMENT i tabel `koereboguserfiles`
--
ALTER TABLE `koereboguserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `leveringsinfo`
--
ALTER TABLE `leveringsinfo`
  MODIFY `order_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `offentligcomments`
--
ALTER TABLE `offentligcomments`
  MODIFY `commentid` int(255) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `offentligorders`
--
ALTER TABLE `offentligorders`
  MODIFY `orderid` int(255) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `offentliguserfiles`
--
ALTER TABLE `offentliguserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `produkt`
--
ALTER TABLE `produkt`
  MODIFY `produkt_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `rengoering`
--
ALTER TABLE `rengoering`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Tilføj AUTO_INCREMENT i tabel `rengoeringcomments`
--
ALTER TABLE `rengoeringcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `rengoeringuserfiles`
--
ALTER TABLE `rengoeringuserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `renovering`
--
ALTER TABLE `renovering`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Tilføj AUTO_INCREMENT i tabel `renoveringcomment`
--
ALTER TABLE `renoveringcomment`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `renoveringuserfiles`
--
ALTER TABLE `renoveringuserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tilføj AUTO_INCREMENT i tabel `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- Tilføj AUTO_INCREMENT i tabel `vikarrekruttering`
--
ALTER TABLE `vikarrekruttering`
  MODIFY `orderid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Tilføj AUTO_INCREMENT i tabel `vikarrekrutteringcomments`
--
ALTER TABLE `vikarrekrutteringcomments`
  MODIFY `commentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Tilføj AUTO_INCREMENT i tabel `vikarrekrutteringuserfiles`
--
ALTER TABLE `vikarrekrutteringuserfiles`
  MODIFY `userfileid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tilføj AUTO_INCREMENT i tabel `webshoporder`
--
ALTER TABLE `webshoporder`
  MODIFY `webshoporder_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `alarmovervaagning`
--
ALTER TABLE `alarmovervaagning`
  ADD CONSTRAINT `alarmovervaagning_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `alarmovervaagning_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `alarmovervaagningcomments`
--
ALTER TABLE `alarmovervaagningcomments`
  ADD CONSTRAINT `alarmovervaagningcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarmovervaagningcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `alarmovervaagning` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `alarmovervaagningcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `alarmovervaagninguserfiles`
--
ALTER TABLE `alarmovervaagninguserfiles`
  ADD CONSTRAINT `alarmovervaagninguserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `alarmovervaagning` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `digitalisering`
--
ALTER TABLE `digitalisering`
  ADD CONSTRAINT `digitalisering_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `digitalisering_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `digitaliseringcomments`
--
ALTER TABLE `digitaliseringcomments`
  ADD CONSTRAINT `digitaliseringcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `digitaliseringcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `digitalisering` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `digitaliseringcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `digitaliseringuserfiles`
--
ALTER TABLE `digitaliseringuserfiles`
  ADD CONSTRAINT `digitaliseringuserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `digitalisering` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `erhvervlejemaal`
--
ALTER TABLE `erhvervlejemaal`
  ADD CONSTRAINT `erhvervlejemaal_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `erhvervlejemaal_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `erhvervlejemaalcomments`
--
ALTER TABLE `erhvervlejemaalcomments`
  ADD CONSTRAINT `erhvervlejemaalcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `erhvervlejemaalcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `erhvervlejemaal` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `erhvervlejemaalcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `erhvervlejemaaluserfiles`
--
ALTER TABLE `erhvervlejemaaluserfiles`
  ADD CONSTRAINT `erhvervlejemaaluserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `erhvervlejemaal` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `fagforening`
--
ALTER TABLE `fagforening`
  ADD CONSTRAINT `fagforening_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `fagforening_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `fagforeningcomment`
--
ALTER TABLE `fagforeningcomment`
  ADD CONSTRAINT `fagforeningcomment_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `fagforeningcomment_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `fagforening` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `fagforeningcomment_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `fagforeninguserfiles`
--
ALTER TABLE `fagforeninguserfiles`
  ADD CONSTRAINT `fagforeninguserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `fagforening` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `jobtilbud`
--
ALTER TABLE `jobtilbud`
  ADD CONSTRAINT `jobtilbud_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `jobtilbud_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `jobtilbudcomment`
--
ALTER TABLE `jobtilbudcomment`
  ADD CONSTRAINT `jobtilbudcomment_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `jobtilbudcomment_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `jobtilbud` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `jobtilbudcomment_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `jobtilbuduserfiles`
--
ALTER TABLE `jobtilbuduserfiles`
  ADD CONSTRAINT `jobtilbuduserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `jobtilbud` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `kaffeloesning`
--
ALTER TABLE `kaffeloesning`
  ADD CONSTRAINT `kaffeloesning_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `kaffeloesning_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `kaffeloesningcomments`
--
ALTER TABLE `kaffeloesningcomments`
  ADD CONSTRAINT `kaffeloesningcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `kaffeloesningcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `kaffeloesning` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `kaffeloesningcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `kaffeloesninguserfiles`
--
ALTER TABLE `kaffeloesninguserfiles`
  ADD CONSTRAINT `kaffeloesninguserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `kaffeloesning` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `koerebog`
--
ALTER TABLE `koerebog`
  ADD CONSTRAINT `koerebog_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `koerebog_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `koerebogcomments`
--
ALTER TABLE `koerebogcomments`
  ADD CONSTRAINT `koerebogcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `koerebogcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `koerebog` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `koerebogcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `koereboguserfiles`
--
ALTER TABLE `koereboguserfiles`
  ADD CONSTRAINT `koereboguserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `koerebog` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `offentligcomments`
--
ALTER TABLE `offentligcomments`
  ADD CONSTRAINT `offentligcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `offentligcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `offentligorders` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `offentligcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `offentligorders`
--
ALTER TABLE `offentligorders`
  ADD CONSTRAINT `offentligorders_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `offentligorders_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `offentliguserfiles`
--
ALTER TABLE `offentliguserfiles`
  ADD CONSTRAINT `offentliguserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `offentligorders` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `rengoering`
--
ALTER TABLE `rengoering`
  ADD CONSTRAINT `rengoering_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `rengoering_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `rengoeringcomments`
--
ALTER TABLE `rengoeringcomments`
  ADD CONSTRAINT `rengoeringcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `rengoeringcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `rengoering` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `rengoeringcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `rengoeringuserfiles`
--
ALTER TABLE `rengoeringuserfiles`
  ADD CONSTRAINT `rengoeringuserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `rengoering` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `renovering`
--
ALTER TABLE `renovering`
  ADD CONSTRAINT `renovering_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `renovering_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `renoveringcomment`
--
ALTER TABLE `renoveringcomment`
  ADD CONSTRAINT `renoveringcomment_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `renoveringcomment_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `renovering` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `renoveringcomment_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `renoveringuserfiles`
--
ALTER TABLE `renoveringuserfiles`
  ADD CONSTRAINT `renoveringuserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `renovering` (`orderid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `vikarrekruttering`
--
ALTER TABLE `vikarrekruttering`
  ADD CONSTRAINT `vikarrekruttering_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `vikarrekruttering_ibfk_2` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`);

--
-- Begrænsninger for tabel `vikarrekrutteringcomments`
--
ALTER TABLE `vikarrekrutteringcomments`
  ADD CONSTRAINT `vikarrekrutteringcomments_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE CASCADE,
  ADD CONSTRAINT `vikarrekrutteringcomments_ibfk_2` FOREIGN KEY (`orderid`) REFERENCES `vikarrekruttering` (`orderid`) ON DELETE CASCADE,
  ADD CONSTRAINT `vikarrekrutteringcomments_ibfk_3` FOREIGN KEY (`adminuid`) REFERENCES `adminuser` (`adminuid`) ON DELETE CASCADE;

--
-- Begrænsninger for tabel `vikarrekrutteringuserfiles`
--
ALTER TABLE `vikarrekrutteringuserfiles`
  ADD CONSTRAINT `vikarrekrutteringuserfiles_ibfk_1` FOREIGN KEY (`orderid`) REFERENCES `vikarrekruttering` (`orderid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
